//Takes 2 lists and reverses them one after another into a new list
//Return {List} the updated list 
function championsReverse() {
  var countryList = getColumn("FIFA Men's World Cup Results", "Champions");
  var returnCountry = [];
  var dateList = getColumn("FIFA Men's World Cup Results", "Year");
  var returnDate = [];
  var returnCountryDate = [];
  for (var i = countryList.length - 1; i >= 0; i--) {
    appendItem(returnCountry, countryList[i]);
  }
  for (var a = dateList.length - 1; a >= 0; a--) {
    appendItem(returnDate, dateList[a]);
  }
  for (var b = 0; b < returnCountry.length; b++) {
    appendItem(returnCountryDate, returnCountry[b]);
    appendItem(returnCountryDate, returnDate[b]);
  }
  return returnCountryDate;
}
console.log(championsReverse());
//Searches for the amount of times a country appears in the champions column 
// countryName {string} name of the country
//Return {Number} the amount of times the country appears in the champions column 
function championsCount(countryName) {
  var countryList = getColumn("FIFA Men's World Cup Results", "Champions");
  var countryCount = 0;
  for (var i = 0; i < countryList.length; i++) {
    if (countryList[i] == countryName) {
      countryCount = countryCount + 1;
    }
  }
  return countryCount;
}
console.log(championsCount("Argentina"));
